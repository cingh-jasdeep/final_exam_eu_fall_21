package com.example.good_news_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
