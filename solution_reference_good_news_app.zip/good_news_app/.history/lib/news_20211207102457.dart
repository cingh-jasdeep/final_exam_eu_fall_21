class News {
  final String newsText, newsImagePath;
  News(this.newsText, this.newsImagePath);
}
