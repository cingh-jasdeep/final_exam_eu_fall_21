import 'package:flutter/material.dart';
import 'package:good_news_app/news.dart';
import 'package:good_news_app/news_brain.dart';

class NewsPage extends StatefulWidget {
  const NewsPage({Key? key}) : super(key: key);

  @override
  _NewsPageState createState() => _NewsPageState();
}

class _NewsPageState extends State<NewsPage> {
  final NewsBrain _newsBrain = NewsBrain();
  final ScrollController _scrollController = ScrollController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        elevation: 0.0,
        title: Text(
          'Good News',
          style: TextStyle(
            color: Colors.black,
            fontSize: 26.0,
            fontFamily: 'Abhaya Libre',
          ),
        ),
        backgroundColor: Colors.grey[300],
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            child: Image.asset(
              _newsBrain.getNewsImagePath(),
              fit: BoxFit.cover,
            ),
          ),
          SizedBox(
            height: 10.0,
          ),
          Expanded(
            child: SingleChildScrollView(
              controller: _scrollController,
              child: Text(
                _newsBrain.getNewsText(),
                style: TextStyle(
                  fontSize: 20.0,
                ),
              ),
            ),
          ),
          SizedBox(
            height: 10.0,
          ),
          GestureDetector(
            onTap: () {
              setState(() {
                _newsBrain.goToNextNews();
                if (_scrollController.hasClients) {
                  _scrollController.jumpTo(0);
                }
              });
            },
            child: Container(
              padding: EdgeInsets.all(16.0),
              color: Colors.grey[800],
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    'More News 👼',
                    style: TextStyle(
                      fontSize: 22.0,
                      color: Colors.white,
                    ),
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}
