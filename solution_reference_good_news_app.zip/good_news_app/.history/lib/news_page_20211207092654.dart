import 'package:flutter/material.dart';

class NewsPage extends StatefulWidget {
  const NewsPage({Key? key}) : super(key: key);

  @override
  _NewsPageState createState() => _NewsPageState();
}

class _NewsPageState extends State<NewsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        title: Text(
          'Good News',
          style: TextStyle(
            color: Colors.black,
            fontSize: 26.0,
            fontFamily: 'Abhaya Libre',
          ),
        ),
        backgroundColor: Colors.grey[300],
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            child: Image.asset(
              'images/Disabilities_Act.jpg',
              fit: BoxFit.cover,
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              child: Text(
                  'TNIE Impact: Sivakasi Elwin Center gets disabled friendly toilets\nToilets were constructed after The New Indian Express had highlighted the needs of the school on September 19 and raised the question of whether the funds would reach the cause.\nBy Azeefa Fathima\nExpress News Service\nVIRUDHUNAGAR: In less than two months after Collector J Meghanatha Reddy passed the proceedings for the construction of two disabled-friendly toilets, the funds have found its way for the same. Collector opened two disabled-friendly toilets under the \'Udhayam\' scheme in the CSI school for Elwin Centre in Sivakasi for use on the occasion of World Disability Day here on Friday.\n\nToilets were constructed after The New Indian Express had highlighted the needs of the school on September 19 and raised the question of whether the funds would reach the cause. It looks like the universe has indeed conspired in helping them in achieving their needs.\n\nSpeaking at the inauguration event, the collector said though he was exposed to the issues of Persons with Disabilities (PwDs) through his friends, difficulty in using a toilet did not come into his thought up until it a 16-year-old girl in a pension camp at the collectorate raised it.\n\n"Normally toilets at our houses would be small and cannot be easily accessed by PwDs. After the girl explained their plight, I wanted to do something about this, and we devised the \'Udhayam\' scheme. Though we will not be able to construct toilets for everyone immediately, we are doing it in a phased manner based on CSR funds and other fund availability, prioritising women and girls," he said.  \n\nHe further said under the initiative it has been aimed to build at least 100 toilets by the end of this year. Speaking about the need of the school, he said that when the school approached him, though there was no fund at hand, he had made arrangements from his discretionary funds.\n\nThe funds for two other toilets under construction is sponsored by a private sponsor, he added. Stating a saying, he said, "When you want something, all the universe conspires in helping you to achieve it, and I wanted to do this for the differently-abled people. I got in touch with the like-minded people who supported me in taking the project forward," he said.\n\nSchool correspondent M Dayalan Barnabas demanded three things during the function: a paver block road leading to the school; include the widowed women in the school in the scheme where free goats are distributed by the state government and include Elwin Centre in \'Adult Project\' under the PwD welfare department as nearly 50 adult PwDs are residing in the school. Collecter assured to take action.\n\nBackstory\n\nThe Elwin Centre, located in Sivakasi\'s Satchiyapuram was established in 1980 by Selvabai and her husband Reverend Thavaraj David. The school is now working under the model of self-sustenance with limited funding. The school aims to translate its financial model into the lives of its children. As part of the self-sustenance project, they bought 50 country chickens and reared them. "Everything, from feeding the chicken to cleaning the coops, was done by our children. The money coming from the rearing is re-invested in similar ventures.\n\nDuring the earlier interaction with The New Indian Express, they had highlighted two issues: a crunch in funds despite the self-sustenance model and well-wishers; and the lack of disability-friendly toilets for the children who also have physical disabilities.\n\nWhen the latter issue was highlighted to the collector, he had immediately conducted inspections, following which Rs 94,000 was sanctioned in the first phase for the construction of two toilets and mobilised funds through private sponsor for the construction of another two.\n\nEarlier, the district officials, led by the collector, created a project named Udhayam to build accessible toilets in their houses for PwDs, in the district.\n\n\nhttps://www.newindianexpress.com/good-news/2021/dec/04/tnie-impact-sivakasi-elwin-center-getsdisabled-friendly-toilets-2391706.html'),
            ),
          ),
        ],
      ),
    );
  }
}
