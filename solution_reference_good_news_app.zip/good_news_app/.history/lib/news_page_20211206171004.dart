import 'package:flutter/material.dart';

class NewsPage extends StatefulWidget {
  const NewsPage({Key? key}) : super(key: key);

  @override
  _NewsPageState createState() => _NewsPageState();
}

class _NewsPageState extends State<NewsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        title: Text(
          'Good News',
          style: TextStyle(
            color: Colors.black,
            fontSize: 26.0,
            fontFamily: 'Abhaya Libre',
          ),
        ),
        backgroundColor: Colors.grey[300],
      ),
      body: Column(
        children: [
          Expanded(
            child: Image.asset(
              'images/Disabilities_Act.jpg',
            ),
          ),
          Expanded(
              child: SingleChildScrollView(
            child: Text('''
            
            '''),
          )),
        ],
      ),
    );
  }
}
