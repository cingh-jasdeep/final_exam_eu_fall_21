class News {
  final String newsText, newsImagePath;
  News(this.newsImagePath, this.newsText);
}
